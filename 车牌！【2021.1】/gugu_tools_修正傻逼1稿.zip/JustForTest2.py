import gugu_tools_1

x = gugu_tools_1.plate_judge("IIIII")

print(x)