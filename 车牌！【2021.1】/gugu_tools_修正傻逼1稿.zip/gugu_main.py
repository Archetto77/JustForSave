import gugu_tools_1

input_number = 0
while input_number < 3:
    plate_before = input("")
    plate_list = plate_before.split()
    plate = plate_list[0]
    judge_number = gugu_tools_1.plate_judge(plate)
    if judge_number == 0:
        input_number += 1
        continue
    elif judge_number == 2:
        print("This car is allowed to drive.\n")
        input_number += 1
        continue
    elif judge_number == 1:
        if plate_list[2] == "Sat" or plate_list[2] == "Sun":
            print("This car is allowed to drive.\n")
            input_number += 1
            continue
        date = plate_list[1][4]
        current_letter = len(plate)-1
        last_letter = plate[current_letter]
        while not type(last_letter) == int:
            last_letter = current_letter - 1
            current_letter -= 1
            continue
        if (int(date) - int(last_letter)) % 2 == 0:
            print("This car is allowed to drive.\n")
            input_number += 1
            continue
        elif (int(date) - int(last_letter)) % 2 == 1:
            print("This car is not allowed to drive.\n")
            input_number += 1
            continue
