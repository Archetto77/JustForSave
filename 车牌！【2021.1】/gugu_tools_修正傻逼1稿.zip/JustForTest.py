def number_judge(maybe_plate):
    i = 0
    number_letter = 0
    while i < len(maybe_plate):
        if maybe_plate[i].isalpha() is True:
            number_letter += 1
        i += 1
    return number_letter


# 定义一个检查字符串的两个字母是否连续的函数
def continuity_judge(maybe_plate):
    i = 0
    while i < len(maybe_plate):
        if maybe_plate[i].isalpha() is False:
            i += 1
            continue
        else:
            if i == len(maybe_plate)-1:
                return False
            elif maybe_plate[i+1].isalpha() is False:
                return False
            else:
                return True
    return False


# 定义一个检查纯数字字符串是否出现三连重复的函数
def repeat_check(maybe_plate):
    if maybe_plate.isdigit() is False:
        return False
    else:
        i = 2
        while i < len(maybe_plate):
            if maybe_plate[i] == maybe_plate[i-1] == maybe_plate[i-2]:
                return False
            else:
                i += 1
    return True


# 定义一个车牌是不是符合规定、是不是人上人出租车或者新能源车、还是屁民的普通车的函数
def plate_judge(maybe_plate):
    judge_factor = 0
    taxi_factor = 0
    no_tax_factor = 0
    # 车牌要怎么样捏？
    # 1.车牌必须是5位或者6位捏
    if len(maybe_plate) < 5 or len(maybe_plate) > 6:
        print("This number is invalid.\n")
        return 0
    # 2.车牌不可以有I或者O捏
    elif "I" in maybe_plate or "O" in maybe_plate:
        print("This number is invalid.\n")
        return 0
    else:
        # 新能源汽车只能是DF开头结尾捏
        if len(maybe_plate) == 6:
            if maybe_plate[0] == "D" or maybe_plate[0] == "F" or maybe_plate[5] == "D" or maybe_plate[5] == "F":
                if number_judge(maybe_plate) == 1:
                    no_tax_factor += 2
                    return no_tax_factor
                else:
                    print("This number is invalid.\n")
                    return 0
            else:
                print("This number is invalid.\n")
                return 0

        if len(maybe_plate) == 5:
            number_of_letter = number_judge(maybe_plate)
            # 如果有三个以上字母建议直接爬
            if number_of_letter >= 3:
                print("This number is invalid.\n")
                return 0
            # 如果有两个字母，那么必须连续或者首尾
            elif number_of_letter == 2:
                if continuity_judge(maybe_plate) is False:
                    if maybe_plate[0].isalpha() is True and maybe_plate[4].isalpha() is True:
                        judge_factor += 1
                        return judge_factor
                    else:
                        print("This number is invalid.\n")
                        return 0
                else:
                    judge_factor += 1
                    return judge_factor
            # 如果有一个字母，在第四位的话可以没有悬念的滚蛋
            # 然后看一下首位是不是脑瘫出租车
            # 然后爱咋咋地
            elif number_of_letter == 1:
                if maybe_plate[3].isalpha() is True:
                    print("This number is invalid.\n")
                    return 0
                elif maybe_plate[0] == "T" or maybe_plate[0] == "X":
                    taxi_factor += 2
                    return taxi_factor
                else:
                    judge_factor += 1
                    return judge_factor
            # 如果全是数字【拜托，这种车牌才比较帅】，那就不可以有三个连续的数字重复哟~
            elif number_of_letter == 0:
                if repeat_check(maybe_plate) is False:
                    print("This number is invalid.\n")
                    return 0
                else:
                    judge_factor += 1
                    return judge_factor


x = plate_judge("222O1")

print(x)
